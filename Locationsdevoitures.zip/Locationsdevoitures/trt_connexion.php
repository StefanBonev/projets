<?php
$con = mysqli_connect("localhost","root","","bons");
$req = "SELECT *
FROM compte
WHERE'".$_POST['user']."' = user
AND'".$_POST['psw']."'= mdp ";

$res = mysqli_query($con, $req);
$don= mysqli_fetch_array($res);


if (mysqli_num_rows($res)==1)
//{
  session_start();
  $_SESSION['user']=$don['user'];
  $_SESSION['psw']=$don['mdp'];
  $_SESSION['statut']=$don['statut'];
  $_SESSION['nom']=$don['nom'];
  $_SESSION['prenom']=$don['prenom'];
 
  header('location:index.php?page=accueil');
//}
/*else ()
{
  header('location:index.php?page=connexion');
}*/

?>
