-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 09 jan. 2020 à 11:34
-- Version du serveur :  10.4.8-MariaDB
-- Version de PHP :  7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bons`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `idCat` int(20) NOT NULL,
  `nomCat` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`idCat`, `nomCat`) VALUES
(1, 'Citadine'),
(2, 'Routiere'),
(3, 'Luxe'),
(4, 'Utilitaire'),
(5, 'Transport');

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `idCompte` int(10) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `raisonSocial` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `adresse` varchar(20) NOT NULL,
  `numTel` int(15) NOT NULL,
  `pays` varchar(10) NOT NULL,
  `ville` varchar(15) NOT NULL,
  `user` varchar(15) NOT NULL,
  `mdp` varchar(15) NOT NULL,
  `age` int(5) NOT NULL,
  `statut` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `compte`
--

INSERT INTO `compte` (`idCompte`, `nom`, `prenom`, `raisonSocial`, `email`, `adresse`, `numTel`, `pays`, `ville`, `user`, `mdp`, `age`, `statut`) VALUES
(1, 'Jean', 'Dubo', 'NationEnterprise', 'j.d@nation_e.com', '89 rue fleur', 9586321, 'France', 'Paris', 'admin', 'admin', 50, 'administrateur'),
(2, 'Julien', 'François', 'CarMen', 'j.f@carmen.fr', '45 rue sec', 9874563, 'France ', 'Toulouse', 'user ', 'user', 30, 'professionnel'),
(3, 'Toni', 'Zurkov', 'FastCar', 't.z@fastcar.fr', '89', 9586123, 'Angleterre', 'London', 'user2', 'user2', 28, 'particulier');

-- --------------------------------------------------------

--
-- Structure de la table `etatres`
--

CREATE TABLE `etatres` (
  `cdEtat` int(10) NOT NULL,
  `nomRes` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `etatres`
--

INSERT INTO `etatres` (`cdEtat`, `nomRes`) VALUES
(1, 'enCours'),
(2, 'enAttente'),
(3, 'finaliser'),
(4, 'refuser'),
(5, 'programmer');

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE `reservation` (
  `numRes` int(10) NOT NULL,
  `dateDeb` date NOT NULL,
  `dateFin` date NOT NULL,
  `DateReservation` date NOT NULL,
  `user` varchar(30) NOT NULL,
  `montantVerser` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `reservation`
--

INSERT INTO `reservation` (`numRes`, `dateDeb`, `dateFin`, `DateReservation`, `user`, `montantVerser`) VALUES
(4, '2020-01-22', '2020-01-01', '2020-01-15', 'admin', 5000),
(5, '2020-01-22', '2020-01-15', '2020-01-22', 'user ', 8000),
(6, '2020-01-15', '2020-01-18', '2020-01-23', 'user2', 40000);

-- --------------------------------------------------------

--
-- Structure de la table `voiture`
--

CREATE TABLE `voiture` (
  `idVoiture` int(10) NOT NULL,
  `info` varchar(3000) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `prix` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `voiture`
--

INSERT INTO `voiture` (`idVoiture`, `info`, `photo`, `prix`) VALUES
(1, 'Allumage / extinction automatiques des phares\r\nAirbags frontaux, latéraux avant et rideaux\r\nVolant cuir multifonction réglable en hauteur et profondeur\r\nJantes en alliage 16\" Twin Spoke Silver\r\nInstrumentation de bord muni d\'un écran 3.5\'\' monochrome blanc avec ordinateur de bord', 'opel-crossland-x.jpg', 8000),
(3, 'Enfin, du point de vue de son autonomie, et donc de sa consommation de carburant, cette dernière reste très raisonnable en vitesse de croisière, et hors encombrements urbains, en particulier avec les plus récents moteurs diesel. Bien sûr, dans le cas d\'un monocorps, l’appétit sera plus élevé tout comme le volume.', 'fiat-500-cab.jpg', 5000),
(4, 'La  Skoda Scala est la nouvelle berline compacte basée sur la  la plate-forme A0 MQB du groupe Volkswagen. Elle inaugure une nouvelle évolution de l\'identité stylistique du constructeur tchèque. Disponible dès le 1er semestre de l\'année 2019, elle dispose de plusieurs motorisations essence ou Diesel (TSI et TDI).\r\n\r\n', 'skoda_scala.png', 3000);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`idCat`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`idCompte`);

--
-- Index pour la table `etatres`
--
ALTER TABLE `etatres`
  ADD PRIMARY KEY (`cdEtat`);

--
-- Index pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`numRes`);

--
-- Index pour la table `voiture`
--
ALTER TABLE `voiture`
  ADD PRIMARY KEY (`idVoiture`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categorie`
--
ALTER TABLE `categorie`
  MODIFY `idCat` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `compte`
--
ALTER TABLE `compte`
  MODIFY `idCompte` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `etatres`
--
ALTER TABLE `etatres`
  MODIFY `cdEtat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `numRes` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `voiture`
--
ALTER TABLE `voiture`
  MODIFY `idVoiture` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
