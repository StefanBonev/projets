<?php
$con = mysqli_connect("localhost","root","","bons");



$datedeb=$_POST['datedeb'];
$datefin=$_POST['datefin'];
$dateres=$_POST['dateres'];
$user=$_POST['user'];
$montant=$_POST['montant'];

$req="INSERT INTO reservation( dateDeb, dateFin,DateReservation,user,montantVerser)
 VALUES('$datedeb','$datefin','$dateres','$user','$montant')";
 echo $req;
if($req)
{
$res = mysqli_query($con,$req);
mysqli_close ($con);
//sleep(23);
header("location:index.php?page=reservation");
}
?>