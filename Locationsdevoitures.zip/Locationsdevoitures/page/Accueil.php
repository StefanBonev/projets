<!DOCTYPE html>
<?php
 session_start();
 print_r($_SESSION);
  ?> 
<html>
    <title>Bons Gars Rental </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
         p {
    color: white;
            }
        body {font-family: "Times New Roman", Georgia, Serif;}
        h1,h2,h3,h4,h5,h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
    </style>


        <!-- Header -->
        <header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
            <img src="logo.png" alt=""/>

        </header>

    <body style="background-color:#FF8C00;">
    
        
       

        <div class="w3-container w3-padding-64" id="Accueil.html">
            <h1>Bienvenue</h1><br>
            <h2>Qui sommes nous</h2>
            <p>Les 3 Bons Gars Rental est un site très fiable, simple e rapide d’utilisation pour louer une voiture de tous les type, en passant pas la petite citadine au véhicule de luxe. 
                Vous avez la possibilité de louer des camionnettes pour déménagements ou pour transports lourds.Vous pouvez nous contacter via notre page contact directement sur notre site.</p>
    
        </div>    <?php echo $_SESSION['nom'] ;?>
            
    </body>

</html>

