<!DOCTYPE html>
<html>
<body>

    <br> <br>
<h2>CONNEXION</h2>
<p>Identification</p>


<form action="../Locationsdevoitures/trt_connexion.php" methode="post"> 
<a>Username:</a><br>
<input type="text" name="user" required>
<br>
<a>User password:<a><br>
<input type="password" name="psw" required>
<br>
<br>
<button type = "submit" style="width:225"  > <a href = "../Locationsdevoitures/page/FormulaireInscription.php"> Inscription </a> </button>  
<button type = "submit" style="width:225"  > Connexion </button>  

<br><br>
</form>


</body>
</html>