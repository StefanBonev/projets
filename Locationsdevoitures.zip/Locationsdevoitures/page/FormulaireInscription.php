<!DOCTYPE html>
<html>
    <title>Bons Gars Rental </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
         p {
    color: white;
}
        body {font-family: "Times New Roman", Georgia, Serif;}
        h1,h2,h3,h4,h5,h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
    </style>


        <!-- Header -->
        <header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
            <img src="logo.png" alt=""/>

        </header>

<body style="background-color:#FF8C00;">
    <h2>FORMULAIRE D'INSCRIPTION</h2>
    <p>Veuillez entrer les informations ci-dessous:</p>

    <form action="../trt_inscription.php" methode="post">
        First name:<br>
        <input name="Firstname" type="text" maxlength="20" required>
        <br>
        Last name:<br>
        <input name="LastName" type="text" maxlength="20" required>
        <br>
        Age:<br>
        <input type="text" name="age">
        <br>
        Social reason:<br>
        <input type="text" name="Socialreason" required>
        <br>
        Statut:<br>
            <select name='statut' size='1'>
                    <option value='particulier'>Particulier</option>
                    <option value='professionnel'>Professionnel</option>
                    <option value='adminstrateur'>Administrateur</option>
            </select>
          <br>
        Mail:<br>
        <input type="email" name="Mail">
        <br>
        Adress:<br>
        <input name="Adress" type="text" maxlength="30">
        <br>
        Phone number:<br>
        <input type="tel" name="Phonenumber">
        <br>
        pays:<br>
        <input type="text" name="pays">
        <br>
        ville:<br>
        <input type="text" name="ville">
        <br>
        user:<br>
        <input type="text" name="user">
        <br>
        password:<br>
        <input type="text" name="password">

        <br><br>

        <button type = "submit"> Valider </button>

    </form>
    <br>
    <button type = "submit" style="width:225"  > <a href = "index.php?page=accueil"> Retour page d'accueil </a> </button>
      
    </body>
    
</html>

