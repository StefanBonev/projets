<!DOCTYPE html>
<html>
    <title>Bons Gars Rental </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
         p {
    color: white;
}
        body {font-family: "Times New Roman", Georgia, Serif;}
        h1,h2,h3,h4,h5,h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
    </style>


        <!-- Header -->
        <header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
            <img src="logo.png" alt=""/>

        </header>

    <body style="background-color:#FF8C00;">

        <h2>FORMULAIRE DE RESERVATION DE VOITURE </h2>
<p>Veuillez entrer les informations ci-dessous:</p>

<form action="../trt_resV.php" methode="post">
Date debut:<br>
<input name="datedeb" type="date"  maxlength="20" required>
<br>
Date fin:<br>
<input name="datefin" type="date" maxlength="20"   required>
<br>
Date de reservation:<br>
<input type="date" name="dateres" >
<br>
user:<br>
<input type="text" name="user" required>
<br>
montant verser:<br>
<input name="montant" type="text" maxlength="20" required>


<br><br>

<button type = "submit"> Valider </button>

</form>
       

        
            
    </body>
    
</html>

