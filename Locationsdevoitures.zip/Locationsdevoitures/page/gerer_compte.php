<!DOCTYPE html>
<html>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

    <title>Bons Gars Rental </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
         p {
    color: white;
}
        body {font-family: "Times New Roman", Georgia, Serif;}
        h1,h2,h3,h4,h5,h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
    </style>


    <body style="background-color:#FF8C00;">
    <?php
    $con = mysqli_connect("localhost","root","","bons");
                $req="SELECT DISTINCT * FROM compte";
                $res = mysqli_query($con,$req); echo"<br> <br> <br> <br> <br> ";
                echo"<table >
                <tr>
                <th>Nom</th>
                <th>Prenom</th>
                <th>Raison Social</th>
                <th>Email</th>
                <th>Adresse</th>
                <th>Numero de telephone</th>
                <th>Pays</th>
                <th>Ville</th>
                <th>Statut</th>
                <th>MODIFIER UN COMPTE</th>
                <th>SUPPRIMER UN COMPTE</th> 
                </tr>";

                while($ligne=mysqli_fetch_array($res))
                {
                echo"<tr>";
                echo"<td>".$ligne['nom']."</td>";
                echo"<td>".$ligne['prenom']."</td>";
                echo"<td>".$ligne['raisonSocial']."</td>";
                echo"<td>".$ligne['email']."</td>";
                echo"<td>".$ligne['adresse']."</td>";
                echo"<td>".$ligne['numTel']."</td>";
                echo"<td>".$ligne['pays']."</td>";
                echo"<td>".$ligne['ville']."</td>";
                echo"<td>".$ligne['statut']."</td>";
               

                //Bouton update
                echo "<td><button><a href=''>Modifier</a></button></td>";
                echo "<td><button><a href=''>DELETE</a></button></td>";
                echo "</tr>";
                }
                echo"</table>";
    ?>
        <br><br>     <button><a href=''>RETOUR PAGE DE GESTION</a></button>
    </body>

</html>

