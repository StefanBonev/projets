<!DOCTYPE html>
<?php
 session_start();
 //print_r($_SESSION);
  ?> 
<html>
<!-- Bootstrap core CSS -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="css/modern-business.css" rel="stylesheet">
    <title>Bons Gars Rental </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style>
         p {
    color: white;
}
        body {font-family: "Times New Roman", Georgia, Serif;}
        h1,h2,h3,h4,h5,h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
    </style>


        <!-- Header -->
        <header class="w3-display-container w3-content w3-wide" style="max-width:1600px;min-width:500px" id="home">
            <img src="logo.png" alt=""/>

        </header>

    <body style="background-color:#FF8C00;">
    
        
       
    <?php 
        $con = mysqli_connect("localhost","root","","bons");
        $req = "SELECT * FROM voiture";
        $res = mysqli_query($con,$req);
                

            while($ligne=mysqli_fetch_array($res))
            { 
                    echo"<div class='row'>"; echo"<div class='col-md-7'>";
                            echo"<img src='../Locationsdevoitures/img/".$ligne['photo']."' class='img-fluid rounded mb-3 mb-md-0'  alt='' >";
                            echo "<p>".$ligne['info']."</p>";
                    echo "<h3>".$ligne['prix']."$</h3>";
                    echo"<button type = 'submit' style='width:225'  > <a href = '../Locationsdevoitures/page/reservationvoitu.php'> Reserver </a> </button> <br> <br>";
                            echo"</a>";
                    echo"</div> </div>"; 
                    
                    
                    
            }
                    mysqli_close($con);
        ?> 
            
    </body>

</html>

