<?php
$con = mysqli_connect("localhost","root","","bons");

$FIRSTN = $_POST['Firstname'];
$LASTN=$_POST['LastName'];
$AGE=$_POST['age'];
$SOCIALR=$_POST['Socialreason'];
$MAIL=$_POST['Mail'];
$TEL=$_POST['Phonenumber'];
$ADRESS=$_POST['Adress'];
$PAYS=$_POST['pays'];
$VILLE=$_POST['ville'];
$USER=$_POST['user'];
$PASSWORD=$_POST['password'];
$STATUT=$_POST['statut'];

$req="INSERT INTO compte(idcompte,nom,prenom,raisonSocial,email,adresse,numTel,pays,ville,user,pwd,age,statut)
VALUES(null,'$LASTN','$FIRSTN','$SOCIALR','$MAIL','$ADRESS','$TEL','$PAYS','$VILLE','$USER','$PASSWORD','$AGE','$STATUT')";

if($req)
{

//echo "Success";
$res = mysqli_query($con,$req);
mysqli_close ($con);
//sleep(23);
header("location:index.php?page=connexion");

}
else
{

//echo "Error";
//sleep(23);
header("location:../Locationsdevoitures/page/FormulaireInscription.php");

}

?>
